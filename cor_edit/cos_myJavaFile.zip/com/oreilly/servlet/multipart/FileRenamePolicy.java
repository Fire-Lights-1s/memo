package com.oreilly.servlet.multipart;

import java.io.File;

public interface FileRenamePolicy {
   File rename(File var1);
}
