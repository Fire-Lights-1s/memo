package com.oreilly.servlet;

public class ParameterNotFoundException extends Exception {
   public ParameterNotFoundException() {
   }

   public ParameterNotFoundException(String s) {
      super(s);
   }
}
